<template>
  <div class="new_protest">
    <h3>Make a New Protest</h3>
    <input type="text" v-model="protest_name" placeholder="Name of Protest"><br>
    <input type="text" v-model="protest_description" placeholder="Description of Protest"><br>
    <input type="text" v-model="datetime" placeholder="Date Time"><br>
    <v-btn v-on:click="createProtest">Submit Protest</v-btn>
  </div>
</template>

<script>
import firebase from 'firebase'
import {db} from '../firebase'
import {auth} from '../firebase'

  export default {
    name: 'newProtest',
    data: function() {
      return {
        //set the fields of the application
        protest_name: '',
        protest_description: '',
        location: '',
        social_interests: '',
        datetime: '',
        uid: null
      }
    },
    beforeMount(){
      //let user be authenticated and then get their id
      let currentUser = auth.currentUser;
      if (currentUser){
        this.uid = currentUser.uid;
      }
      else {
        let authListenerUnsubscribe = auth.onAuthStateChange(user => {
          if (user) {
            //recrusive function to continue searching for the userid
            this.uid = currentUser.uid;
            authListenerUnsubscribe();
          }
        })
      }
    },
    methods: {
      //user creates a protest that will be sent to firebase
      createProtest: function() {

        db.ref('protests' + '/' + this.protest_name).set({
          name: this.protest_name,
          organizerUid: this.uid,
          description: this.protest_description,
          datetime: this.datetime,
          status: 'inactive',
          participants: 0,
          people: []
        })
        //set to the user addiionaly protests
        db.ref('users/' + this.uid + '/currentProtests/').push({
          name: this.protest_name
        })
        this.$router.replace('organizer')
      }
    }
  }
</script>


<style scoped>
  .new_protest {
    margin-top: 40px;
  }
  input {
    margin: 10px 0;
    width: 20%;
    padding: 15px;
  }
  button {
    margin-top: 20px;
    width: 10%;
    cursor: pointer;
  }
  P {
    margin-top: 40px;
    font-size: 13px;
  }
  p a {
    text-decoration: underline;
    cursor: pointer;
  }
</style>
